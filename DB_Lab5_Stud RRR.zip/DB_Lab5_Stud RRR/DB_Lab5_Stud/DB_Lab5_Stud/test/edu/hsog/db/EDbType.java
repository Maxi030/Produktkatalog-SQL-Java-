package edu.hsog.db;

public enum EDbType {
    ORACLE,
    MYSQL,
    MARIADB
}
