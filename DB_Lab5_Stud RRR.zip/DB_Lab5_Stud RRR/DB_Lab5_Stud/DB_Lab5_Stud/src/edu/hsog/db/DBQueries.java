
package edu.hsog.db;

import java.io.InputStream;
import java.sql.*;

public class DBQueries {
    public static ResultSet getAllGadgets() throws SQLException {
        String query = "SELECT * FROM gadgets ORDER BY url";
        Connection con = Globals.getPoolConnection();
        if (con == null) {
            System.out.println("Verbindung zur Datenbank konnte nicht hergestellt werden.");
        } else {
            System.out.println("Verbindung zur Datenbank erfolgreich.");
        }
        Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        return stmt.executeQuery(query);
    }
    public static void saveComment(String gadgetUrl, String email, String comment, int rating) throws SQLException {
        Connection con = Globals.getPoolConnection();
        String mergeQuery = "MERGE INTO bewertung b " +
                "USING (SELECT ? AS url, ? AS email FROM dual) src " +
                "ON (b.url = src.url AND b.email = src.email) " +
                "WHEN MATCHED THEN " +
                "    UPDATE SET kommentar = ?, gefallen = ? " +
                "WHEN NOT MATCHED THEN " +
                "    INSERT (url, email, kommentar, gefallen) VALUES (?, ?, ?, ?)";

        try (PreparedStatement stmt = con.prepareStatement(mergeQuery)) {
            // Set parameters for the `USING` clause
            stmt.setString(1, gadgetUrl); // url in `src`
            stmt.setString(2, email);     // email in `src`

            // Set parameters for the `WHEN MATCHED` clause
            stmt.setString(3, comment);  // kommentar to update
            stmt.setInt(4, rating);      // gefallen to update

            // Set parameters for the `WHEN NOT MATCHED` clause
            stmt.setString(5, gadgetUrl); // url to insert
            stmt.setString(6, email);     // email to insert
            stmt.setString(7, comment);   // kommentar to insert
            stmt.setInt(8, rating);       // gefallen to insert

            stmt.executeUpdate();
        } finally {
            con.close();
        }
    }







    public static ResultSet searchBestRatedGadget() throws SQLException {
        String query = "SELECT * FROM gadgets WHERE url IN (SELECT gadget_url FROM comments GROUP BY gadget_url ORDER BY AVG(rating) DESC FETCH FIRST 1 ROW ONLY)";
        Connection con = Globals.getPoolConnection();
        Statement stmt = con.createStatement();
        return stmt.executeQuery(query);
    }

    static int count() {
        Statement stat = null;
        ResultSet rs = null;
        Connection con = Globals.getPoolConnection();

        try {
            stat = con.createStatement();
            String q = "select count(*) from gadgets";
            System.out.println(q);
            rs = stat.executeQuery(q);
            rs.next();
            return rs.getInt(1);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                if(rs!=null)rs.close();
                if(stat!=null)stat.close();
                if(con!=null)con.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

        }
    }

    static boolean login(String username, String password) {
        Statement stat = null;
        ResultSet rs = null;
        Connection con = Globals.getPoolConnection();

        try {
            stat = con.createStatement();
            String q = "select count(*) \n"+
                    "from users \n"+
                    "where email='"+username+"' and passwd='"+password+"'";

            System.out.println(q);
            rs = stat.executeQuery(q);
            rs.next();
            int c= rs.getInt(1);
            return (c==1);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                if(rs!=null)rs.close();
                if(stat!=null)stat.close();
                if(con!=null)con.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

        }
    }
    // Fügt ein neues Gadget hinzu oder aktualisiert ein bestehendes
    public static void saveGadget(String url, String email, String keywords, String description, InputStream coverImage) throws SQLException {
        Connection con = Globals.getPoolConnection();
        String checkExistQuery = "SELECT COUNT(*) FROM gadgets WHERE url = ?";
        PreparedStatement checkStmt = con.prepareStatement(checkExistQuery);
        checkStmt.setString(1, url);
        ResultSet rs = checkStmt.executeQuery();
        rs.next();
        int count = rs.getInt(1);

        if (count > 0) {
            // Gadget existiert, Update durchführen
            String updateQuery = "UPDATE gadgets SET email = ?, keywords = ?, description = ?, cover = ? WHERE url = ?";
            PreparedStatement updateStmt = con.prepareStatement(updateQuery);
            updateStmt.setString(1, email);
            updateStmt.setString(2, keywords);
            updateStmt.setString(3, description);
            if (coverImage != null) {
                updateStmt.setBlob(4, coverImage);
            } else {
                updateStmt.setNull(4, Types.BLOB);
            }
            updateStmt.setString(5, url);
            updateStmt.executeUpdate();
            System.out.println("Gadget erfolgreich aktualisiert.");
        } else {
            // Gadget existiert nicht, Insert durchführen
            String insertQuery = "INSERT INTO gadgets (url, email, keywords, description, cover) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement insertStmt = con.prepareStatement(insertQuery);
            insertStmt.setString(1, url);
            insertStmt.setString(2, email);
            insertStmt.setString(3, keywords);
            insertStmt.setString(4, description);
            if (coverImage != null) {
                insertStmt.setBlob(5, coverImage);
            } else {
                insertStmt.setNull(5, Types.BLOB);
            }
            insertStmt.executeUpdate();
            System.out.println("Gadget erfolgreich hinzugefügt.");
        }

        con.close();
    }

    // Löscht ein Gadget basierend auf der URL
    public static void deleteGadget(String url) throws SQLException {
        Connection con = Globals.getPoolConnection();
        String deleteQuery = "DELETE FROM gadgets WHERE url = ?";
        PreparedStatement deleteStmt = con.prepareStatement(deleteQuery);
        deleteStmt.setString(1, url);
        int rowsAffected = deleteStmt.executeUpdate();

        if (rowsAffected > 0) {
            System.out.println("Gadget erfolgreich gelöscht.");
        } else {
            System.out.println("Gadget nicht gefunden.");
        }

        con.close();
    }
}
