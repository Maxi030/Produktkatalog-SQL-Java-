package edu.hsog.db;

import javax.swing.*;
import javax.swing .*;
import java.awt .*;
import java.awt.event .*;
import java.sql .*;
import java.util.List;
import java.util.ArrayList;
import java.awt.Dimension;


public class Main {
    public static void main (String []args) throws UnsupportedLookAndFeelException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        JFrame j = generateJFrame();
        j.setVisible(true);

        Globals.initConnectionPool();
    }

    public static JFrame generateJFrame(){
        JFrame jframe=new JFrame("WINDOW");
        jframe.setSize(1920,800);
        GUI gui = new GUI();

        jframe.getContentPane().add(gui.getPanel());
        gui.getMasterPanel().setPreferredSize(new Dimension(1920,800));
        return jframe;
    }
}



