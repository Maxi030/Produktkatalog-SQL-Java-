package edu.hsog.db;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.InputStream;
import java.sql.ResultSet;
import java.sql.*;                   // Für Datenbankoperationen wie Connection, ResultSet, SQLException
import java.sql.SQLException;   // Für die Behandlung von SQL-Ausnahmen


public class GUI {
    private JPanel MasterPanel;
    private JButton exitButton;
    private JButton innitConnectionPoolButton;
    private JButton countButton;
    private JLabel JCount;
    private JPanel JPanel;
    private JButton ImageButton;
    private JLabel ImageLabel;
    private JTextField username;
    private JButton registerButton;
    private JButton loginButton;
    private JTextField password;
    private JLabel status;
    private JButton prevButton;
    private JButton clearButton;
    private JButton searchButton;
    private JButton lastButton;
    private JButton firstButton;
    private JButton nextButton;
    private JButton saveItemButton;
    private JButton deleteItemButton;
    private JTextField urlTextField;
    private JTextField keywordsTextField;
    private JTextArea commentsTextArea;
    private JTextArea descriptionTextArea;
    private JLabel ownerLabel;
    private JTextField commentsTextField;
    private JLabel ratingLabel;
    private JSlider slider1;
    private JButton SaveRatingWIthComment;
    private ResultSet gadgetResultSet;



    // Initialisierung der Gadget-Daten
    public void initGadgets() {
        try {
            gadgetResultSet = DBQueries.getAllGadgets();
            if (gadgetResultSet.next()) {
                loadGadgetIntoFields();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(MasterPanel, "Fehler beim Laden der Gadgets.", "Datenbankfehler", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadGadgetIntoFields() {
        try {
            String url = gadgetResultSet.getString("url");
            String email = gadgetResultSet.getString("email");
            String keywords = gadgetResultSet.getString("keywords");
            String description = gadgetResultSet.getString("description");
            Blob cover = gadgetResultSet.getBlob("cover");

            // Lade Daten in die entsprechenden Textfelder
            urlTextField.setText(url);
            username.setText(email);
            keywordsTextField.setText(keywords);
            descriptionTextArea.setText(description);

            // Setze den Besitzer in das Label
            ownerLabel.setText(email);

            // Berechne den Mittelwert der Bewertungen und zeige ihn an
            double averageRating = getAverageRating(url); // Methode zur Berechnung des Durchschnitts
            ratingLabel.setText(String.format(String.valueOf(averageRating)));

            //
            // Setze die Min- und Max-Werte des Sliders auf 1 und 5
            slider1.setMinimum(1);
            slider1.setMaximum(5);

// Setze die Schrittweite auf 1 (die Schritte werden jetzt nur 1, 2, 3, 4 und 5 sein)
            slider1.setMajorTickSpacing(1);
            slider1.setMinorTickSpacing(1);

// Setze den Slider so, dass er an den Markierungen haftet
            slider1.setSnapToTicks(true);

// Zeige die Markierungen (Ticks) an
            slider1.setPaintTicks(true);
            slider1.setPaintLabels(true);

            // Überprüfe, ob der Blob leer oder null ist
            if (cover != null && cover.length() > 0) {
                ImageIcon icon = Converter.blob2ImageIcon(cover); // Wandelt das Blob in ein ImageIcon um
                if (icon != null) {
                    ImageLabel.setIcon(icon);  // Setzt das ImageIcon im Label
                    ImageLabel.setText("");    // Löscht den Text im Label
                } else {
                    ImageLabel.setIcon(null);  // Falls das Bild nicht geladen werden konnte
                    ImageLabel.setText("Bild konnte nicht geladen werden");
                }
            } else {
                ImageLabel.setIcon(null);  // Kein Bild vorhanden
                ImageLabel.setText("Kein Bild verfügbar");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    private double getAverageRating(String gadgetUrl) {
        double averageRating = 0.0;
        // Die Tabelle heißt Bewertung und wir greifen auf die Spalte gefallen zu
        String query = "SELECT AVG(gefallen) AS average_rating FROM Bewertung WHERE url = ?";

        try (Connection con = Globals.getPoolConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {

            stmt.setString(1, gadgetUrl); // Setzt die URL des Gadgets als Parameter
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    averageRating = rs.getDouble("average_rating");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return averageRating;
    }




    private void saveGadget() {
        String url = urlTextField.getText();            // URL des Gadgets
        String email = username.getText();              // Der eingeloggte Benutzer (Besitzer)
        String keywords = keywordsTextField.getText();  // Keywords
        String description = descriptionTextArea.getText();  // Beschreibung

        // Optional: Bild hinzufügen, falls vorhanden
        InputStream coverImageStream = null;
        if (ImageLabel.getIcon() != null) {
            ImageIcon icon = (ImageIcon) ImageLabel.getIcon();
            Blob coverImageBlob = Converter.imageIcon2Blob(icon, Globals.getPoolConnection());  // Bild in Blob umwandeln
            try {
                // Blob in InputStream umwandeln
                coverImageStream = coverImageBlob.getBinaryStream();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        try {
            // Gadget in der DB speichern (Einfügen oder Aktualisieren)
            DBQueries.saveGadget(url, email, keywords, description, coverImageStream);
            //JOptionPane.showMessageDialog(MasterPanel, "Gadget erfolgreich gespeichert.", "Erfolg", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            e.printStackTrace();
            //JOptionPane.showMessageDialog(MasterPanel, "Fehler beim Speichern des Gadgets.", "Fehler", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteGadget() {
        String url = urlTextField.getText();  // URL des zu löschenden Gadgets

        try {
            // Gadget aus der DB löschen
            DBQueries.deleteGadget(url);
            //JOptionPane.showMessageDialog(MasterPanel, "Gadget erfolgreich gelöscht.", "Erfolg", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            e.printStackTrace();
            //JOptionPane.showMessageDialog(MasterPanel, "Fehler beim Löschen des Gadgets.", "Fehler", JOptionPane.ERROR_MESSAGE);
        }
    }




    public JPanel getPanel() {
        return MasterPanel;
    }

    public JButton getButton1() {
        return exitButton;
    }


    public GUI() {

        countButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Anzahl der Gadgets aus der Datenbank abfragen
                    int count = DBQueries.count();

                    // Ergebnis im Label anzeigen
                    JCount.setText("Count: " + count);
                } catch (Exception ex) {
                    ex.printStackTrace();
                    //JOptionPane.showMessageDialog(MasterPanel, "Fehler beim Abrufen der Gadget-Anzahl.", "Datenbankfehler", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Beende die Anwendung
                System.exit(0);
            }
        });
        ImageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Erstelle den JFileChooser
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setName("imageJFch");
                fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
                fileChooser.setDialogTitle("Wählen Sie ein Bild");

                // Setze einen Dateifilter, um nur Bilder anzuzeigen
                FileNameExtensionFilter filter = new FileNameExtensionFilter("Bilddateien", "jpg", "png", "gif");
                fileChooser.setFileFilter(filter);

                // Zeige den Dialog an
                int returnValue = fileChooser.showOpenDialog(null);

                // Überprüfe, ob der Benutzer eine Datei ausgewählt hat
                if (returnValue == JFileChooser.APPROVE_OPTION) {
                    // Hole die ausgewählte Datei
                    File selectedFile = fileChooser.getSelectedFile();
                    System.out.println("Ausgewählte Datei: " + selectedFile.getAbsolutePath());

                    // Lade das Bild als Icon
                    Icon imageIcon = Converter.loadIconFromFile(selectedFile.getAbsolutePath());

                    // Setze das Bild im JLabel
                    ImageLabel.setIcon(imageIcon);
                    ImageLabel.repaint(); // Damit das Bild sofort angezeigt wird
                } else {
                    System.out.println("Kein Bild ausgewählt.");
                }
            }
        });


        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String user = username.getText();
                String pass = password.getText();
                boolean loggedIn = DBQueries.login(user, pass);
                if (loggedIn) {
                    status.setText("logged in");
                } else {
                    status.setText("not logged in");
                }
            }
        });

        firstButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Cursor zurück auf den Anfang setzen
                    if (gadgetResultSet != null) {
                        gadgetResultSet.beforeFirst(); // Setzt den Cursor an den Anfang des ResultSets
                        if (gadgetResultSet.next()) {  // Geht zur ersten Zeile
                            loadGadgetIntoFields();
                            System.out.println("loadgadgets");
                        } else {
                            System.out.println("ResultSet ist leer oder keine Gadgets vorhanden.");
                        }
                    } else {
                        System.out.println("ResultSet ist null");
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        lastButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    if (gadgetResultSet.last()) {
                        loadGadgetIntoFields();
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    if (gadgetResultSet.next()) {
                        loadGadgetIntoFields();
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        prevButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Überprüfen, ob der Cursor nicht am Anfang des ResultSets ist
                    if (gadgetResultSet != null && !gadgetResultSet.isFirst()) {
                        if (gadgetResultSet.previous()) {  // Cursor bewegt sich zum vorherigen Gadget
                            loadGadgetIntoFields();
                            System.out.println("Previous Gadget geladen.");
                        }
                    } else {
                        System.out.println("Du befindest dich bereits am ersten Gadget.");
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });


        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    ResultSet bestRatedGadget = DBQueries.searchBestRatedGadget();
                    if (bestRatedGadget.next()) {
                        gadgetResultSet = bestRatedGadget; // Setze das ResultSet auf das Suchergebnis
                        loadGadgetIntoFields();
                    } else {
                        JOptionPane.showMessageDialog(MasterPanel, "Kein Gadget gefunden.", "Ergebnis leer", JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        innitConnectionPoolButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Globals.initConnectionPool();
                status.setText("verbunden");
                initGadgets();
            }
        });
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lösche den Text in der commentsTextArea
                commentsTextArea.setText("");
                commentsTextField.setText("");
                descriptionTextArea.setText("");
                keywordsTextField.setText("");
                ownerLabel.setText("");
                urlTextField.setText("");
                ImageLabel.setIcon(null);
                Globals.initConnectionPool();
                status.setText("verbunden");
                initGadgets();
                commentsTextArea.setText("");
                commentsTextField.setText("");
                descriptionTextArea.setText("");
                keywordsTextField.setText("");
                ownerLabel.setText("");
                urlTextField.setText("");
                ImageLabel.setIcon(null);
            }
        });
        saveItemButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                // Überprüfen, ob alle erforderlichen Felder ausgefüllt sind
                String url = urlTextField.getText().trim();
                String email = username.getText().trim();
                String keywords = keywordsTextField.getText().trim();
                String description = descriptionTextArea.getText().trim();

                // Falls eines der Felder leer ist, eine Fehlermeldung anzeigen
                if (url.isEmpty() || email.isEmpty() || keywords.isEmpty() || description.isEmpty()) {
                    //JOptionPane.showMessageDialog(MasterPanel, "Bitte füllen Sie alle Felder aus.", "Fehler", JOptionPane.ERROR_MESSAGE);
                    return;  // Verhindert, dass die Methode fortgesetzt wird
                }

                // Falls alles ausgefüllt ist, Gadget speichern
                saveGadget();  // Die Methode, die das Gadget speichert
            }
        });

        deleteItemButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String currentUser = username.getText();  // Der eingeloggte Benutzer
                String owner = ownerLabel.getText().replace("Owner: ", "");  // Der Besitzer des Gadgets aus dem Label

                // Überprüfen, ob der Benutzer der Besitzer ist
                if (currentUser.equals(owner)) {
                    // Löschen des Gadgets
                    deleteGadget();
                } else {
                    //JOptionPane.showMessageDialog(MasterPanel, "Du kannst nur dein eigenes Gadget löschen!",
                    //"Zugriff verweigert", JOptionPane.ERROR_MESSAGE);
                }
            }
        });


        SaveRatingWIthComment.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String currentUser = username.getText();  // Der eingeloggte Benutzer
                System.out.println(currentUser);
                String owner = ownerLabel.getText().replace("Owner: ", "");  // Der Besitzer des Gadgets aus dem Label

                // Überprüfen, ob der Benutzer der Besitzer ist
                if (currentUser.equals(owner)) {
                    // Speichern oder Ändern des Gadgets
                    saveGadget();  // Die Methode, die das Gadget speichert

                    // Kommentar aus dem JTextField holen
                    String comment = commentsTextField.getText().trim();  // Lese den Text aus dem Kommentar-Feld und entferne führende/abschließende Leerzeichen

                    // Holen des Sliderwerts
                    int rating = slider1.getValue();  // Holen des aktuellen Sliderwerts

                    if (!comment.isEmpty()) {
                        // Hole den bestehenden Text aus der JTextArea und füge den neuen Kommentar hinzu
                        String existingText = commentsTextArea.getText();  // Hole den bestehenden Text
                        commentsTextArea.setText(existingText + comment );  // Füge den neuen Kommentar hinzu

                        // Lösche das Kommentar-Feld
                        commentsTextField.setText("");  // Löscht den Kommentar im Textfeld

                        // Sicherstellen, dass die URL des aktuell ausgewählten Gadgets verwendet wird
                        String selectedGadgetUrl = urlTextField.getText().trim();  // URL des aktuell ausgewählten Gadgets

                        // Speichern des Kommentars und der Bewertung in der Datenbank
                        try {
                            DBQueries.saveComment(selectedGadgetUrl, currentUser, comment, rating);  // Methode zum Speichern von Kommentar und Bewertung
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                            //JOptionPane.showMessageDialog(MasterPanel, "Fehler beim Speichern des Kommentars.", "Fehler", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        try {
                            String selectedGadgetUrl = urlTextField.getText().trim();  // URL des aktuell ausgewählten Gadgets
                            DBQueries.saveComment(selectedGadgetUrl, currentUser, "", rating);  // Methode zum Speichern von Kommentar und Bewertung
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                            //JOptionPane.showMessageDialog(MasterPanel, "Fehler beim Speichern des Kommentars.", "Fehler", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    //JOptionPane.showMessageDialog(MasterPanel, "Du bist nicht der Besitzer dieses Gadgets!", "Zugriff verweigert", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

    }


        public JPanel getMasterPanel(){
        return MasterPanel;
    }

}

